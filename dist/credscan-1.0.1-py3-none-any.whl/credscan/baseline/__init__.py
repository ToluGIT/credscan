"""
Baseline management for handling false positive exclusions.
"""
from .manager import BaselineManager

__all__ = ['BaselineManager']
