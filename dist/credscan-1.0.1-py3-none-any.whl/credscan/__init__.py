# src/credscan/__init__.py
"""
CredScan:  credential and secret detection tool.
"""

__version__ = "1.0.1"
