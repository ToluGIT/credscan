# Configuration
API_SECRET = "this_is_a_real_secret_12345"
DEBUG_PASSWORD = "TEST_DEBUG_PASSWORD"

def get_connection_string():
    return "postgres://user:password123@localhost:5432/mydb"