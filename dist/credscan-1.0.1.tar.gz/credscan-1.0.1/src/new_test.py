# This credential should be excluded by pattern
TEST_SECRET_KEY = "TEST_SECRET_KEY_ABCDEF123"
