"""
Reporting and output formatting for credential detection results.
"""
from .reporter import Reporter

__all__ = ['Reporter']
