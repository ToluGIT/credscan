#!/usr/bin/env python3
from setuptools import setup

# This is a simple setup.py that defers to setup.cfg
if __name__ == "__main__":
    setup()
